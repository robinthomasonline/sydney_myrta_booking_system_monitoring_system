// DOM elements
const urlInput = document.getElementById('urlInput');
const useCurrentTabBtn = document.getElementById('useCurrentTab');
const thresholdInput = document.getElementById('thresholdInput');
const intervalInput = document.getElementById('intervalInput');
const soundAlertCheckbox = document.getElementById('soundAlert');
const desktopNotificationCheckbox = document.getElementById('desktopNotification');
const refreshPageCheckbox = document.getElementById('refreshPage');
const refreshIntervalInput = document.getElementById('refreshIntervalInput');
const refreshIntervalSection = document.getElementById('refreshIntervalSection');
const refreshIntervalHelp = document.getElementById('refreshIntervalHelp');
const intervalHelp = document.getElementById('intervalHelp');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusIndicator = document.getElementById('statusIndicator');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const statsSection = document.getElementById('statsSection');
const lastCheck = document.getElementById('lastCheck');
const nextCheck = document.getElementById('nextCheck');
const changeCount = document.getElementById('changeCount');
const lastChange = document.getElementById('lastChange');
const changeLog = document.getElementById('changeLog');
const changeLogList = document.getElementById('changeLogList');

let monitoringActive = false;

// Load saved settings
async function loadSettings() {
    const result = await chrome.storage.local.get([
        'threshold',
        'interval',
        'refreshInterval',
        'soundAlert',
        'desktopNotification',
        'refreshPage',
        'monitoredUrl',
        'monitoringActive',
        'changeCount',
        'lastChange',
        'changeLog'
    ]);

    if (result.threshold) thresholdInput.value = result.threshold;
    if (result.interval) intervalInput.value = result.interval;
    if (result.refreshInterval) refreshIntervalInput.value = result.refreshInterval;
    if (result.soundAlert !== undefined) soundAlertCheckbox.checked = result.soundAlert;
    if (result.desktopNotification !== undefined) desktopNotificationCheckbox.checked = result.desktopNotification;
    if (result.refreshPage !== undefined) refreshPageCheckbox.checked = result.refreshPage;
    if (result.monitoredUrl) urlInput.value = result.monitoredUrl;
    if (result.monitoringActive) {
        monitoringActive = result.monitoringActive;
        updateUI();
    }
    if (result.changeCount) changeCount.textContent = result.changeCount;
    if (result.lastChange) lastChange.textContent = formatTime(result.lastChange);
    if (result.changeLog && result.changeLog.length > 0) {
        displayChangeLog(result.changeLog);
    }
}

// Save settings
async function saveSettings() {
    await chrome.storage.local.set({
        threshold: parseInt(thresholdInput.value),
        interval: parseInt(intervalInput.value),
        refreshInterval: parseInt(refreshIntervalInput.value),
        soundAlert: soundAlertCheckbox.checked,
        desktopNotification: desktopNotificationCheckbox.checked,
        refreshPage: refreshPageCheckbox.checked,
        monitoredUrl: urlInput.value
    });
}

// Get current tab URL
async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) {
        urlInput.value = tab.url;
        await saveSettings();
    }
}

// Start monitoring
async function startMonitoring() {
    const url = urlInput.value.trim();
    if (!url) {
        alert('Please enter a URL or use current tab');
        return;
    }

    // Validate URL
    try {
        new URL(url);
    } catch (e) {
        alert('Please enter a valid URL (e.g., https://example.com)');
        return;
    }

    // Validate refresh interval if refresh page is enabled
    const refreshPage = refreshPageCheckbox.checked;
    if (refreshPage) {
        const refreshInterval = parseInt(refreshIntervalInput.value);
        if (refreshInterval < 120) {
            alert('Refresh interval must be at least 120 seconds.');
            refreshIntervalInput.value = 120;
            refreshIntervalInput.focus();
            return;
        }
    }

    await saveSettings();
    
    // Send message to background script
    const message = {
        action: 'start',
        url: url,
        threshold: parseInt(thresholdInput.value),
        interval: parseInt(intervalInput.value),
        refreshInterval: refreshPage ? parseInt(refreshIntervalInput.value) : null,
        soundAlert: soundAlertCheckbox.checked,
        desktopNotification: desktopNotificationCheckbox.checked,
        refreshPage: refreshPageCheckbox.checked
    };
    
    chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
            alert('Error starting monitoring: ' + chrome.runtime.lastError.message);
        }
    });

    monitoringActive = true;
    await chrome.storage.local.set({ monitoringActive: true });
    updateUI();
    
    // Request initial next check time after a short delay
    setTimeout(() => {
        updateNextCheckTime();
    }, 1000);
}

// Stop monitoring
async function stopMonitoring() {
    chrome.runtime.sendMessage({ action: 'stop' });
    monitoringActive = false;
    await chrome.storage.local.set({ monitoringActive: false });
    updateUI();
}

// Update UI based on monitoring state
function updateUI() {
    if (monitoringActive) {
        startBtn.disabled = true;
        stopBtn.disabled = false;
        urlInput.disabled = true;
        useCurrentTabBtn.disabled = true;
        thresholdInput.disabled = true;
        intervalInput.disabled = true;
        refreshIntervalInput.disabled = true;
        soundAlertCheckbox.disabled = true;
        desktopNotificationCheckbox.disabled = true;
        refreshPageCheckbox.disabled = true;
        statusDot.className = 'status-dot active';
        statusText.textContent = 'Monitoring';
        statsSection.style.display = 'block';
    } else {
        startBtn.disabled = false;
        stopBtn.disabled = true;
        urlInput.disabled = false;
        useCurrentTabBtn.disabled = false;
        thresholdInput.disabled = false;
        refreshIntervalInput.disabled = false;
        soundAlertCheckbox.disabled = false;
        desktopNotificationCheckbox.disabled = false;
        refreshPageCheckbox.disabled = false;
        statusDot.className = 'status-dot';
        statusText.textContent = 'Stopped';
        // Re-apply refresh page state to enable/disable check interval
        updateIntervalHelp();
    }
}

// Format time
function formatTime(timestamp) {
    if (!timestamp || timestamp === 0) return 'Never';
    const date = new Date(timestamp);
    if (isNaN(date.getTime())) return 'Never';
    return date.toLocaleString();
}

// Display change log
function displayChangeLog(logs) {
    if (!logs || logs.length === 0) {
        changeLog.style.display = 'none';
        return;
    }

    changeLog.style.display = 'block';
    changeLogList.innerHTML = '';
    
    // Show last 5 changes
    const recentLogs = logs.slice(-5).reverse();
    recentLogs.forEach(log => {
        const logItem = document.createElement('div');
        logItem.className = 'change-log-item';
        logItem.innerHTML = `
            <div class="log-time">${formatTime(log.timestamp)}</div>
            <div class="log-details">${log.pixelsChanged} pixels changed</div>
        `;
        changeLogList.appendChild(logItem);
    });
}

// Update interval help text based on refresh page setting
function updateIntervalHelp() {
    if (refreshPageCheckbox.checked) {
        // Show refresh interval section and hide/disable check interval
        refreshIntervalSection.style.display = 'block';
        intervalInput.disabled = true;
        intervalHelp.textContent = 'Check interval is calculated automatically from refresh interval';
        
        // Update refresh interval help text
        const refreshInterval = parseInt(refreshIntervalInput.value) || 120;
        const minInterval = refreshInterval - refreshInterval / 2;
        const maxInterval = refreshInterval + refreshInterval / 2;
        refreshIntervalHelp.textContent = `Check interval will vary between ${minInterval.toFixed(0)} and ${maxInterval.toFixed(0)} seconds`;
    } else {
        // Hide refresh interval section and enable check interval
        refreshIntervalSection.style.display = 'none';
        intervalInput.disabled = false;
        intervalHelp.textContent = 'Time between checks';
        intervalInput.min = 5;
    }
}

// Event listeners
useCurrentTabBtn.addEventListener('click', getCurrentTab);
startBtn.addEventListener('click', startMonitoring);
stopBtn.addEventListener('click', stopMonitoring);
refreshPageCheckbox.addEventListener('change', updateIntervalHelp);
refreshIntervalInput.addEventListener('input', () => {
    if (refreshPageCheckbox.checked) {
        const value = parseInt(refreshIntervalInput.value);
        if (value < 120) {
            refreshIntervalInput.value = 120;
        }
    }
    updateIntervalHelp();
});
intervalInput.addEventListener('input', () => {
    if (refreshPageCheckbox.checked && parseInt(intervalInput.value) < 120) {
        intervalInput.value = 120;
    }
});

// Update next check time
function updateNextCheckTime() {
    if (!monitoringActive) {
        nextCheck.textContent = 'N/A';
        return;
    }
    
    // Request next check time from background
    chrome.runtime.sendMessage({ action: 'getNextCheckTime' }, (response) => {
        if (response && response.nextCheckTime) {
            nextCheck.textContent = formatTime(response.nextCheckTime);
        } else {
            nextCheck.textContent = 'Calculating...';
        }
    });
}

// Listen for updates from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'status_update') {
        // Always update last check time
        if (message.lastCheck) {
            lastCheck.textContent = formatTime(message.lastCheck);
        }
        
        // Update next check time
        if (message.nextCheckTime) {
            nextCheck.textContent = formatTime(message.nextCheckTime);
        } else {
            updateNextCheckTime();
        }
        
        if (message.changeDetected) {
            changeCount.textContent = parseInt(changeCount.textContent) + 1;
            lastChange.textContent = formatTime(Date.now());
            chrome.storage.local.get(['changeLog'], (result) => {
                const logs = result.changeLog || [];
                logs.push({
                    timestamp: Date.now(),
                    pixelsChanged: message.pixelsChanged
                });
                // Keep only last 20 entries
                const recentLogs = logs.slice(-20);
                chrome.storage.local.set({ changeLog: recentLogs });
                chrome.storage.local.set({ changeCount: recentLogs.length });
                chrome.storage.local.set({ lastChange: Date.now() });
                displayChangeLog(recentLogs);
            });
        }
    }
});

// Periodically update next check time when monitoring is active
setInterval(() => {
    if (monitoringActive) {
        updateNextCheckTime();
    }
}, 5000); // Update every 5 seconds

// Initialize
loadSettings();
updateUI();
updateIntervalHelp();

