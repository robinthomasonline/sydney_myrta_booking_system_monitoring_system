// Content script - runs in the context of web pages
// This can be used for additional page monitoring if needed

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getPageInfo') {
        sendResponse({
            url: window.location.href,
            title: document.title,
            readyState: document.readyState
        });
    } else if (message.action === 'playSound') {
        // Play sound from content script
        try {
            const alertUrl = chrome.runtime.getURL('alert.mp3');
            const audio = new Audio(alertUrl);
            audio.volume = 0.8;
            audio.preload = 'auto';
            
            audio.onerror = () => {
                // Fallback to beep
                try {
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    oscillator.frequency.value = 800;
                    oscillator.type = 'sine';
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.5);
                } catch (e) {}
            };
            
            audio.play().catch(() => {
                // Fallback to beep
                try {
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    oscillator.frequency.value = 800;
                    oscillator.type = 'sine';
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.5);
                } catch (e) {}
            });
        } catch (error) {
            // Silent fail
        }
        sendResponse({ success: true });
    }
    return true;
});
