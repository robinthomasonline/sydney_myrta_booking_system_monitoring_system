// Background service worker for monitoring


let monitoringActive = false;
let monitoringInterval = null;
let currentTabId = null;
let currentUrl = null;
let prevScreenshot = null;
let nextCheckTime = null;
let config = {
    threshold: 1000,
    interval: 60,
    soundAlert: true,
    desktopNotification: true
};



// Listen for messages from popup and offscreen
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'start') {
        startMonitoring(message);
        sendResponse({ status: 'started' });
    } else if (message.action === 'stop') {
        stopMonitoring();
        sendResponse({ status: 'stopped' });
    } else if (message.action === 'getNextCheckTime') {
        sendResponse({ nextCheckTime: nextCheckTime });
    } else if (message.type === 'compare_result') {
        // Handle comparison result from offscreen
        return true;
    }
    return true;
});




// Start monitoring
async function startMonitoring(message) {

    
    if (monitoringActive) {

        stopMonitoring();
    }

    const refreshPage = message.refreshPage !== undefined ? message.refreshPage : false;
    let interval = message.interval || 60;
    let refreshInterval = message.refreshInterval || 120;
    
    // Enforce minimum 120 seconds for refresh interval
    if (refreshPage && refreshInterval < 120) {
        refreshInterval = 120;
    }
    


    // If refresh is enabled, calculate interval dynamically
    if (refreshPage) {
        // Calculate random interval between refreshInterval - refreshInterval/2 and refreshInterval + refreshInterval/2
        const minInterval = refreshInterval - refreshInterval / 2;
        const maxInterval = refreshInterval + refreshInterval / 2;
        interval = minInterval + Math.random() * (maxInterval - minInterval);
    }

    config = {
        threshold: message.threshold || 1000,
        interval: interval,
        refreshInterval: refreshInterval,
        soundAlert: message.soundAlert !== undefined ? message.soundAlert : true,
        desktopNotification: message.desktopNotification !== undefined ? message.desktopNotification : true,
        refreshPage: refreshPage
    };

    currentUrl = message.url;

    
    // Try to find tab with the URL
    const tabs = await chrome.tabs.query({ url: currentUrl });

    if (tabs.length > 0) {
        currentTabId = tabs[0].id;

    } else {
        // If tab not found, try to open it

        const tab = await chrome.tabs.create({ url: currentUrl, active: false });
        currentTabId = tab.id;

    }

    monitoringActive = true;
    prevScreenshot = null;


    // Use the same setInterval pattern for both modes
    // Start monitoring loop

    startMonitoringInterval();
    
    // Do initial check

    checkForChanges();
}

// Start monitoring interval - same pattern for both refresh and non-refresh
function startMonitoringInterval() {

    if (!monitoringActive) {

        return;
    }
    
    // Calculate interval
    let interval = config.interval;
    if (config.refreshPage) {
        // For refresh mode, calculate dynamic interval
        const minInterval = config.refreshInterval - config.refreshInterval / 2;
        const maxInterval = config.refreshInterval + config.refreshInterval / 2;
        interval = minInterval + Math.random() * (maxInterval - minInterval);
    } else {

    }
    
    // Clear any existing interval
    if (monitoringInterval) {

        clearInterval(monitoringInterval);
    }
    
    // Set interval - same pattern for both modes
    // Calculate and store next check time
    nextCheckTime = Date.now() + (interval * 1000);
    
    monitoringInterval = setInterval(() => {
        if (monitoringActive) {
            checkForChanges();
            
            // For refresh mode, restart interval with new calculated time
            if (config.refreshPage) {
                startMonitoringInterval(); // This will recalculate and restart
            } else {
                // For non-refresh mode, update next check time
                nextCheckTime = Date.now() + (config.interval * 1000);
            }
        }
    }, interval * 1000);
    

}

// Stop monitoring
function stopMonitoring() {
    monitoringActive = false;
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
    }
    prevScreenshot = null;
    currentTabId = null;
    currentUrl = null;
    nextCheckTime = null;
}

// Check for changes
async function checkForChanges() {
    if (!monitoringActive || !currentTabId) {
        return;
    }
    
    // Send status update at start of check
    try {
        chrome.runtime.sendMessage({
            type: 'status_update',
            lastCheck: Date.now(),
            nextCheckTime: nextCheckTime,
            changeDetected: false,
            pixelsChanged: 0
        });
    } catch (error) {
        // Silent fail
    }
    


    try {
        let beforeScreenshot = null;
        let afterScreenshot = null;

        if (config.refreshPage) {

            
            // Step 1: Take screenshot BEFORE refresh
            try {

                const tab = await chrome.tabs.get(currentTabId);

                const window = await chrome.windows.get(tab.windowId);
                
                // Make sure the tab is active in its window for accurate capture
                if (tab.active === false) {

                    await chrome.tabs.update(currentTabId, { active: true });
                    // Wait a bit for tab to become active
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
                
                // Use captureVisibleTab with the window ID
                beforeScreenshot = await chrome.tabs.captureVisibleTab(window.id, {
                    format: 'png'
                });

            } catch (error) {

            }

            // Step 2: Refresh the page
            try {

                // Check if tab still exists
                let tab;
                try {
                    tab = await chrome.tabs.get(currentTabId);
                } catch (error) {
                    // Tab might have been closed, try to find it again

                    const tabs = await chrome.tabs.query({ url: currentUrl });
                    if (tabs.length > 0) {
                        currentTabId = tabs[0].id;
                        tab = await chrome.tabs.get(currentTabId);

                    } else {
                        throw new Error('Tab not found');
                    }
                }
                
                // Only refresh if tab is not a chrome:// or chrome-extension:// page
                if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {

                    
                    // Make sure tab is active for reliable refresh
                    if (!tab.active) {

                        try {
                            await chrome.tabs.update(currentTabId, { active: true });
                            await new Promise(resolve => setTimeout(resolve, 300));
                            // Re-fetch tab to get updated status
                            tab = await chrome.tabs.get(currentTabId);
                        } catch (error) {

                        }
                    }
                    
                    // Make sure window is focused
                    try {
                        const window = await chrome.windows.get(tab.windowId);
                        if (!window.focused) {

                            await chrome.windows.update(tab.windowId, { focused: true });
                            await new Promise(resolve => setTimeout(resolve, 200));
                        }
                    } catch (error) {

                    }
                    
                    // Try to reload the tab

                    try {
                        // Use reload without bypassCache to ensure proper refresh
                        await chrome.tabs.reload(currentTabId);

                    } catch (reloadError) {

                        // Try alternative method - navigate to the same URL (forces refresh)
                        try {

                            await chrome.tabs.update(currentTabId, { url: tab.url });

                        } catch (navError) {

                            // Last resort: try reload with bypassCache
                            try {

                                await chrome.tabs.reload(currentTabId, { bypassCache: true });

                            } catch (finalError) {

                                throw finalError;
                            }
                        }
                    }
                    
                    // Step 3: Wait for page to load completely
                    let attempts = 0;
                    const maxAttempts = 120; // 60 seconds max wait for status
                    
                    while (attempts < maxAttempts) {
                        try {
                            const updatedTab = await chrome.tabs.get(currentTabId);
                            if (updatedTab.status === 'complete') {

                                break;
                            }
                        } catch (error) {
                            // Tab might have been closed during refresh, try to find it again

                            const tabs = await chrome.tabs.query({ url: currentUrl });
                            if (tabs.length > 0) {
                                currentTabId = tabs[0].id;
                            } else {
                                throw new Error('Tab lost and cannot be found');
                            }
                        }
                        await new Promise(resolve => setTimeout(resolve, 500));
                        attempts++;
                    }
                    
                    // Step 4: Wait additional time for dynamic content (refreshInterval/2)
                    const waitTime = (config.refreshInterval * 1000) / 2; // refreshInterval/2 in milliseconds

                    await new Promise(resolve => setTimeout(resolve, waitTime));

                    
                    // Step 5: Take screenshot AFTER refresh

                    try {
                        const tab = await chrome.tabs.get(currentTabId);
                        const window = await chrome.windows.get(tab.windowId);
                        
                        // Make sure the tab is active in its window for accurate capture
                        if (tab.active === false) {

                            await chrome.tabs.update(currentTabId, { active: true });
                            // Wait a bit for tab to become active
                            await new Promise(resolve => setTimeout(resolve, 500));
                        }
                        
                        // Use captureVisibleTab with the window ID
                        afterScreenshot = await chrome.tabs.captureVisibleTab(window.id, {
                            format: 'png'
                        });

                    } catch (error) {

                    }
                } else {

                }
            } catch (error) {

            }
            

        } else {
            // Normal flow: just take one screenshot
            try {
                const tab = await chrome.tabs.get(currentTabId);
                const window = await chrome.windows.get(tab.windowId);
                
                // Make sure the tab is active in its window for accurate capture
                if (tab.active === false) {
                    await chrome.tabs.update(currentTabId, { active: true });
                    // Wait a bit for tab to become active
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
                
                // Use captureVisibleTab with the window ID
                afterScreenshot = await chrome.tabs.captureVisibleTab(window.id, {
                    format: 'png'
                });
            } catch (error) {

            }
        }

        // Step 6: Compare screenshots
        if (config.refreshPage && beforeScreenshot && afterScreenshot) {
            // Compare before and after refresh screenshots
            const diff = await compareScreenshots(beforeScreenshot, afterScreenshot);
            prevScreenshot = afterScreenshot; // Store after screenshot for next cycle
            
            // Always send status update to popup
            try {
                chrome.runtime.sendMessage({
                    type: 'status_update',
                    lastCheck: Date.now(),
                    nextCheckTime: nextCheckTime,
                    changeDetected: false,
                    pixelsChanged: 0
                });
            } catch (error) {

            }

            if (diff > config.threshold) {
                // Change detected!
                
                // Send change notification
                try {
                    chrome.runtime.sendMessage({
                        type: 'status_update',
                        lastCheck: Date.now(),
                        nextCheckTime: nextCheckTime,
                        changeDetected: true,
                        pixelsChanged: diff
                    });
                } catch (error) {

                }

                // Show desktop notification
                if (config.desktopNotification) {
                    try {
                        chrome.notifications.create({
                            type: 'basic',
                            iconUrl: 'icon48.png',
                            title: 'Change Detected!',
                            message: `${diff} pixels changed on ${currentUrl}`
                        });

                    } catch (error) {

                    }
                }

                // Play sound (if possible)
                if (config.soundAlert) {
                    try {
                        playAlertSound();

                    } catch (error) {

                    }
                }
            } else {
            }
        } else if (!config.refreshPage && prevScreenshot && afterScreenshot) {
            // Normal comparison: compare with previous screenshot
            const diff = await compareScreenshots(prevScreenshot, afterScreenshot);
            
            // Always send status update to popup
            try {
                chrome.runtime.sendMessage({
                    type: 'status_update',
                    lastCheck: Date.now(),
                    nextCheckTime: nextCheckTime,
                    changeDetected: false,
                    pixelsChanged: 0
                });
            } catch (error) {

            }

            if (diff > config.threshold) {
                // Change detected!
                
                // Send change notification
                try {
                    chrome.runtime.sendMessage({
                        type: 'status_update',
                        lastCheck: Date.now(),
                        nextCheckTime: nextCheckTime,
                        changeDetected: true,
                        pixelsChanged: diff
                    });
                } catch (error) {

                }

                // Show desktop notification
                if (config.desktopNotification) {
                    try {
                        chrome.notifications.create({
                            type: 'basic',
                            iconUrl: 'icon48.png',
                            title: 'Change Detected!',
                            message: `${diff} pixels changed on ${currentUrl}`
                        });

                    } catch (error) {

                    }
                }

                // Play sound (if possible)
                if (config.soundAlert) {
                    try {
                        playAlertSound();

                    } catch (error) {

                    }
                }
            } else {
            }
            
            prevScreenshot = afterScreenshot; // Store for next comparison
        } else if (afterScreenshot) {
            // First screenshot, just store it

            prevScreenshot = afterScreenshot;
        } else {

        }
    } catch (error) {

        
        // Try to find the tab again
        try {
            const tabs = await chrome.tabs.query({ url: currentUrl });
            if (tabs.length > 0) {
                currentTabId = tabs[0].id;

            } else {
                // Tab closed, stop monitoring

                stopMonitoring();
                return;
            }
        } catch (queryError) {

            stopMonitoring();
            return;
        }
    }
}

// Compare two screenshots (data URLs) and return number of changed pixels
async function compareScreenshots(dataUrl1, dataUrl2) {
    if (!dataUrl1 || !dataUrl2) return 0;

    try {
        // Create offscreen document for canvas operations if it doesn't exist
        const hasOffscreen = await chrome.offscreen.hasDocument();
        if (!hasOffscreen) {
            await chrome.offscreen.createDocument({
                url: 'offscreen.html',
                reasons: ['DOM_SCRAPING'],
                justification: 'Image comparison for change detection'
            });
        }

        // Send images to offscreen document for comparison
        return new Promise((resolve) => {
            const timeout = setTimeout(() => {
                chrome.runtime.onMessage.removeListener(listener);
                resolve(0); // Timeout, assume no change
            }, 10000); // 10 second timeout

            const listener = (message, sender, sendResponse) => {
                if (message.type === 'compare_result') {
                    clearTimeout(timeout);
                    chrome.runtime.onMessage.removeListener(listener);
                    resolve(message.diff);
                }
            };
            chrome.runtime.onMessage.addListener(listener);
            
            // Send message to offscreen document
            // Note: We need to use a different approach since offscreen can't receive messages directly
            // Let's use a simpler approach with fetch and canvas in the offscreen
            chrome.runtime.sendMessage({
                type: 'compare_images',
                image1: dataUrl1,
                image2: dataUrl2
            }).catch(() => {
                clearTimeout(timeout);
                chrome.runtime.onMessage.removeListener(listener);
                resolve(0);
            });
        });
    } catch (error) {

        // Fallback: simple comparison (less accurate)
        return dataUrl1 !== dataUrl2 ? 10000 : 0;
    }
}

// Play alert sound by injecting script into the tab
async function playAlertSound() {
    if (!currentTabId) return;
    
    try {
        // Get the extension URL for alert.mp3
        const alertUrl = chrome.runtime.getURL('alert.mp3');
        
        // Inject a script to play sound in the tab
        await chrome.scripting.executeScript({
            target: { tabId: currentTabId },
            func: (alertSoundUrl) => {
                // Function to play beep sound
                function playBeepSound() {
                    try {
                        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                        const oscillator = audioContext.createOscillator();
                        const gainNode = audioContext.createGain();

                        oscillator.connect(gainNode);
                        gainNode.connect(audioContext.destination);

                        oscillator.frequency.value = 800;
                        oscillator.type = 'sine';

                        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

                        oscillator.start(audioContext.currentTime);
                        oscillator.stop(audioContext.currentTime + 0.5);
                    } catch (error) {
                        // Silent fail
                    }
                }
                
                // Try to play alert.mp3 first, fallback to beep
                try {
                    const audio = new Audio(alertSoundUrl);
                    audio.volume = 0.8;
                    audio.preload = 'auto';
                    
                    // Set up error handler
                    audio.onerror = () => {
                        playBeepSound();
                    };
                    
                    // Try to play - ensure it always plays something
                    const playPromise = audio.play();
                    if (playPromise !== undefined) {
                        playPromise.catch(() => {
                            playBeepSound();
                        });
                    } else {
                        // Fallback if play() doesn't return a promise
                        playBeepSound();
                    }
                } catch (error) {
                    // Fallback to beep if audio element fails
                    playBeepSound();
                }
            },
            args: [alertUrl]
        });
    } catch (error) {
        // If injection fails, try to play sound via content script message
        try {
            chrome.tabs.sendMessage(currentTabId, { action: 'playSound' });
        } catch (msgError) {
            // Silent fail - notification will still show
        }
    }
}

// Handle tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (monitoringActive && tabId === currentTabId && changeInfo.status === 'complete') {
        // Tab finished loading, reset previous screenshot
        prevScreenshot = null;
    }
});

// Handle tab removal
chrome.tabs.onRemoved.addListener((tabId) => {
    if (monitoringActive && tabId === currentTabId) {
        stopMonitoring();
    }
});

// Test: Log when extension is installed or started
chrome.runtime.onInstalled.addListener(() => {

});

chrome.runtime.onStartup.addListener(() => {

});

// Immediate test - this should appear immediately when service worker loads



