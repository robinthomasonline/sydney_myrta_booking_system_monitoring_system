// Offscreen document script for image comparison
// This runs in an offscreen document to access Canvas API

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'compare_images') {
        compareImages(message.image1, message.image2)
            .then(diff => {
                // Send result back to background
                chrome.runtime.sendMessage({
                    type: 'compare_result',
                    diff: diff
                });
            })
            .catch(error => {
                chrome.runtime.sendMessage({
                    type: 'compare_result',
                    diff: 0
                });
            });
        return true; // Keep channel open for async response
    }
});

async function compareImages(dataUrl1, dataUrl2) {
    const img1 = await loadImage(dataUrl1);
    const img2 = await loadImage(dataUrl2);

    if (img1.width !== img2.width || img1.height !== img2.height) {
        return img1.width * img1.height; // Consider all pixels changed if size differs
    }

    const canvas = document.createElement('canvas');
    canvas.width = img1.width;
    canvas.height = img1.height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    // Draw first image and get ImageData
    ctx.drawImage(img1, 0, 0);
    const data1 = ctx.getImageData(0, 0, canvas.width, canvas.height);

    // Draw second image and get ImageData
    ctx.drawImage(img2, 0, 0);
    const data2 = ctx.getImageData(0, 0, canvas.width, canvas.height);

    // Compare pixels
    let diffCount = 0;
    const threshold = 10; // Pixel difference threshold

    for (let i = 0; i < data1.data.length; i += 4) {
        // Compare RGB values (ignore alpha channel)
        const r1 = data1.data[i];
        const g1 = data1.data[i + 1];
        const b1 = data1.data[i + 2];
        
        const r2 = data2.data[i];
        const g2 = data2.data[i + 1];
        const b2 = data2.data[i + 2];

        // Calculate color difference
        const diff = Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
        if (diff > threshold) {
            diffCount++;
        }
    }

    return diffCount;
}

function loadImage(dataUrl) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = dataUrl;
    });
}

