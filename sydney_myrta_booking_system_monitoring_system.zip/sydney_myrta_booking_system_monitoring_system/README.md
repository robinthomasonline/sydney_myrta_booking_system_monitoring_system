# Sydney MyRTA Booking System Monitoring and Alerting System

A browser extension that monitors the Sydney MyRTA booking system for visual changes and alerts you instantly when booking availability changes.

## Quick Start

1. **Unzip** the packed extension
2. **Enable Developer Mode** in your Chrome-based browser
3. **Load the unpacked extension**
4. **Login** to MyRTA website and navigate to the change date screen
5. **Open the extension** and click "Use Current Tab"
6. **Enable "Refresh page before checking"** and set **Refresh Interval to 600 seconds (10 minutes)**
7. **Click "Start Monitoring"**

The extension will automatically refresh the page every 10 minutes and alert you when booking availability changes are detected.

## Installation

### Supported Browsers

Works in Chrome-based browsers:
- Google Chrome
- Microsoft Edge
- Brave Browser
- Opera
- Vivaldi
- Chromium

**Note**: Firefox and Safari are not supported.

### Installation Steps

1. **Unzip the Packed Extension**:
   - Extract the ZIP file to a folder on your computer

2. **Open Browser Extensions Page**:
   - Navigate to `chrome://extensions/` (or `edge://extensions/` for Edge)
   - Or go to Menu → More Tools → Extensions

3. **Enable Developer Mode**:
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the Unpacked Extension**:
   - Click "Load unpacked" button
   - Select the folder containing the extracted extension files
   - The extension will appear as "Booking System Monitor"

5. **Pin the Extension** (Recommended):
   - Click the puzzle icon in your browser toolbar
   - Find "Booking System Monitor"
   - Click the pin icon to keep it visible

## Usage

### MyRTA URLs

- **Login Page**: https://www.myrta.com/wps/portal/extvp/myrta/licence/tbs/tbs-login
- **Change Date Page**: https://www.myrta.com/wps/portal/extvp/myrta/licence/tbs/tbs-change

### Step-by-Step Setup

1. **Login to MyRTA Website**:
   - Navigate to: https://www.myrta.com/wps/portal/extvp/myrta/licence/tbs/tbs-login
   - Log in with your credentials

2. **Navigate to Change Date Screen**:
   - Go to: https://www.myrta.com/wps/portal/extvp/myrta/licence/tbs/tbs-change
   - This is the page you want to monitor for availability changes
   - **Zoom out the page** (press `Ctrl + -` or `Cmd + -` on Mac) so the date change section is fully visible on your screen
   - Make sure the entire date selection area is visible without scrolling

3. **Open the Extension**:
   - Click the "Booking System Monitor" extension icon in your browser toolbar

4. **Configure Settings**:
   - Click "Use Current Tab" to capture the MyRTA page URL
   - ✅ Check "Refresh page before checking"
   - Set **Refresh Interval to 600 seconds (10 minutes)**
   - ✅ Enable "Play sound alert"
   - ✅ Enable "Desktop notification"

5. **Start Monitoring**:
   - Click "Start Monitoring"
   - The status will show "Monitoring" with a green dot
   - The page will automatically refresh every 10 minutes to check for changes

6. **View Statistics**:
   - While monitoring, you can see:
     - Last check time
     - Next check time
     - Number of changes detected
     - Last change timestamp

7. **Stop Monitoring**:
   - Click "Stop Monitoring" to pause
   - Your settings will be saved automatically

### Recommended Settings

- **Refresh Interval**: **600 seconds (10 minutes)**
- **Pixel Threshold**: 1000 (default)
- **Sound Alert**: Enabled
- **Desktop Notification**: Enabled

## Troubleshooting

### Extension Not Working
- Make sure the extension is enabled in `chrome://extensions/`
- Try reloading the extension

### No Changes Detected
- Lower the pixel threshold if needed
- Make sure you're on the correct MyRTA page
- Make sure the date change section is fully visible on screen (zoom out if needed)

### Notifications Not Showing
- Check browser notification settings: `chrome://settings/content/notifications`
- Make sure "Desktop Notification" is enabled in extension settings

---

## Support

If this project was helpful, consider buying me a coffee to support further development:

[![Buy Me A Coffee](https://img.shields.io/badge/Buy%20Me%20A%20Coffee-FFDD00?style=for-the-badge&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/robinthomasonline)

**Buy Me a Coffee**: [https://buymeacoffee.com/robinthomasonline](https://buymeacoffee.com/robinthomasonline)
